package antonioInacioNeto.estoque;

public class Fornecedor {
    private int cnpj;
    private String nome;

    public Fornecedor(int cnpj, String nome) {
        this.cnpj = cnpj;
        this.nome = nome;
    }
}
